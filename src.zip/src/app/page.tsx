import { ProductSection } from '@/shared/components';

import React from 'react';

export default function Home() {
  return (
    <div className='min-h-screen bg-background'>
      <ProductSection />
      <ProductSection />

      <p>content</p>
    </div>
  );
}
