import { User } from '@prisma/client';
import { axiosInstance } from './instance';

export async function getMeClient(): Promise<User | null> {
  try {
    const res = await axiosInstance.get<User>('auth/me', {
      withCredentials: true,
    });
    return res.data;
  } catch {
    return null;
  }
}
