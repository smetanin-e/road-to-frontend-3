import { useUserStore } from '@/store/user';
import { axiosInstance } from './instance';

export async function refreshAccessToken(): Promise<boolean> {
  try {
    const res = await axiosInstance.post('auth/refresh', null, {
      withCredentials: true,
    });

    if (!res.data?.success) {
      return false;
    }

    if (res.data.user) {
      console.log(res.data.user);
      useUserStore.getState().setUser(res.data.user);
    }

    return true;
  } catch (error) {
    console.error('Ошибка в refreshAccessToken:', error);
    return false;
  }
}
