'use client';
import { useUserStore } from '@/store/user';
import { User } from '@prisma/client';
import React, { ReactNode } from 'react';

interface Props {
  initialUser: User | null;
  children: ReactNode;
}

export default function StoreProvider({ initialUser, children }: Props) {
  //const setUser = useUserStore.getState().setUser;

  return <>{children}</>;
}
