import { refreshAccessToken } from '@/shared/services/refresh-access-token';

import { User } from '@prisma/client';
import { create } from 'zustand';

interface UserState {
  user: User | null;
  setUser: (user: User | null) => void;
}

export const useUserStore = create<UserState>((set) => ({
  user: null,
  setUser: (user) => {
    refreshAccessToken();
    set({ user });
  },
}));

// type User = {
//   id: string;
//   email: string;
//   role: string;
//   firstName: string;
//   lastName: string;
// } | null;

// interface UserState {
//   loading: boolean;
//   error: boolean;
//   user: User;
//   getUser: () => Promise<void>;
// }

// export const useUserStore = create<UserState>()((set) => ({
//   loading: true,
//   error: false,
//   user: null,

//   getUser: async () => {
//     try {
//       set({ loading: true, error: false });
//       //до исправления
//       let res = await fetch('api/auth/me', {
//         method: 'GET',
//         credentials: 'include',
//       });

//       if (res.status === 401) {
//         const refreshed = await refreshAccessToken();
//         if (!refreshed) {
//           set({ user: null, error: true });
//           return;
//         }

//         res = await fetch('api/auth/me', {
//           method: 'GET',
//           credentials: 'include',
//         });
//       }

//       if (!res.ok) {
//         set({ user: null, error: true });
//         return;
//       }

//       const data = await res.json();
//       set({ user: data, error: false });
//       return;
//     } catch (error) {
//       console.error(error);
//       set({ error: true });
//     } finally {
//       set({ loading: false });
//     }
//   },
// }));
